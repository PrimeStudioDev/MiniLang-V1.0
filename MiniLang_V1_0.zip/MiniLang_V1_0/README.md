# MiniLang V1.0 (Projeto de Teste)

Este é um **protótipo mínimo** do compilador da MiniLang V1.0.

## Requisitos
- Linux (testado em Arch)
- Python 3
- gcc

## Rodar agora
```bash
cd MiniLang_V1_0
./build.sh
```

Ele vai:
1. Compilar `src/main.lang` -> `out/out.c`
2. Compilar `out/out.c` com gcc -> `out/a.out`
3. Executar `out/a.out`

## O que esta versão suporta
- `import <algo>;` (aceita e ignora semanticamente)
- `fun main() { ... }`
- variáveis com literais:
  - `int x = 123;`
  - `string s = "texto";`
- `println.break(...)` e `println.unbreak(...)`
- também aceita `println.format.break/unbreak(...)` (como alias)

## Próximos passos
- if/else, while/for
- arrays/vectors reais no backend
- classes (parser + geração)
- `import` por pastas (`std/...`)
