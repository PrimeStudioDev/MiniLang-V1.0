#!/usr/bin/env python3
"""MiniLang V1.0 - minimal proof-of-concept compiler.

Supports (for now):
- import studio; / import string; (accepted but not semantically used)
- fun main() { ... }
- variable declarations:
    int name = 123;
    string name = "text";
- println.break(...); and println.unbreak(...);
  Arguments can be string literals, int literals, or identifiers.

Compiles to C (out/out.c). Optionally invokes gcc to build out/a.out.
"""

from __future__ import annotations

import os
import re
import sys
import subprocess
from dataclasses import dataclass
from typing import List, Tuple, Optional

TOKEN_SPEC = [
    ("WS",      r"[ \t\r\n]+"),
    ("COMMENT", r"//[^\n]*"),
    ("MCOMMENT",r"/\*.*?\*/"),
    ("STRING",  r"\"(?:\\.|[^\"\\])*\""),
    ("NUMBER",  r"\d+"),
    ("IDENT",   r"[A-Za-z_][A-Za-z0-9_]*"),
    ("DOT",     r"\."),
    ("LBRACE",  r"\{"),
    ("RBRACE",  r"\}"),
    ("LPAREN",  r"\("),
    ("RPAREN",  r"\)"),
    ("COMMA",   r","),
    ("SEMI",    r";"),
    ("EQ",      r"="),
]

MASTER_RE = re.compile("|".join(f"(?P<{name}>{pat})" for name, pat in TOKEN_SPEC), re.DOTALL)

@dataclass
class Tok:
    typ: str
    val: str
    pos: int

class ParseError(Exception):
    pass


def lex(src: str) -> List[Tok]:
    out: List[Tok] = []
    i = 0
    while i < len(src):
        m = MASTER_RE.match(src, i)
        if not m:
            raise ParseError(f"Unexpected character at {i}: {src[i:i+20]!r}")
        typ = m.lastgroup
        val = m.group(typ)
        if typ in ("WS", "COMMENT", "MCOMMENT"):
            pass
        else:
            out.append(Tok(typ, val, i))
        i = m.end()
    return out

class Parser:
    def __init__(self, toks: List[Tok]):
        self.toks = toks
        self.i = 0

    def peek(self, k: int = 0) -> Optional[Tok]:
        j = self.i + k
        return self.toks[j] if 0 <= j < len(self.toks) else None

    def accept(self, typ: str) -> Optional[Tok]:
        t = self.peek()
        if t and t.typ == typ:
            self.i += 1
            return t
        return None

    def expect(self, typ: str) -> Tok:
        t = self.peek()
        if not t or t.typ != typ:
            raise ParseError(f"Expected {typ} at token {self.i}, got {t.typ if t else 'EOF'}")
        self.i += 1
        return t

    def accept_ident(self, name: str) -> bool:
        t = self.peek()
        if t and t.typ == "IDENT" and t.val == name:
            self.i += 1
            return True
        return False

@dataclass
class VarDecl:
    typ: str  # int|string
    name: str
    value_kind: str  # number|string
    value: str

@dataclass
class PrintCall:
    mode: str  # break|unbreak
    args: List[Tuple[str, str]]  # (kind, value) where kind in string|number|ident

Statement = VarDecl | PrintCall


def parse_program(p: Parser) -> List[Statement]:
    # imports (ignored but validated)
    while p.accept_ident("import"):
        mod = p.expect("IDENT").val
        p.expect("SEMI")
        # allowed: studio/string/bridge/...
        # for this minimal compiler we just accept any identifier.
        _ = mod

    # fun main
    if not p.accept_ident("fun"):
        raise ParseError("Program must start with 'fun main() { ... }'")
    if not p.accept_ident("main"):
        raise ParseError("Expected main")
    p.expect("LPAREN")
    p.expect("RPAREN")
    p.expect("LBRACE")

    stmts: List[Statement] = []
    while not p.accept("RBRACE"):
        t = p.peek()
        if not t:
            raise ParseError("Unexpected EOF inside main")

        # variable decl: int x = 1; | string s = "...";
        if t.typ == "IDENT" and t.val in ("int", "string"):
            typ = p.expect("IDENT").val
            name = p.expect("IDENT").val
            p.expect("EQ")
            vtok = p.peek()
            if not vtok:
                raise ParseError("Expected value")
            if vtok.typ == "NUMBER":
                value_kind = "number"
                value = p.expect("NUMBER").val
            elif vtok.typ == "STRING":
                value_kind = "string"
                value = p.expect("STRING").val
            else:
                raise ParseError("Expected literal number or string")
            p.expect("SEMI")
            stmts.append(VarDecl(typ, name, value_kind, value))
            continue

        # println.break/unbreak call
        if t.typ == "IDENT" and t.val == "println":
            p.expect("IDENT")
            p.expect("DOT")
            mode = p.expect("IDENT").val
            if mode not in ("break", "unbreak", "format"):
                raise ParseError("println only supports .break or .unbreak (and .format is reserved)")

            # allow println.format.break/unbreak as a passthrough (bridge)
            if mode == "format":
                p.expect("DOT")
                mode = p.expect("IDENT").val
                if mode not in ("break", "unbreak"):
                    raise ParseError("println.format only supports .break/.unbreak")

            p.expect("LPAREN")
            args: List[Tuple[str, str]] = []
            if not p.accept("RPAREN"):
                while True:
                    at = p.peek()
                    if not at:
                        raise ParseError("Unexpected EOF in println args")
                    if at.typ == "STRING":
                        args.append(("string", p.expect("STRING").val))
                    elif at.typ == "NUMBER":
                        args.append(("number", p.expect("NUMBER").val))
                    elif at.typ == "IDENT":
                        args.append(("ident", p.expect("IDENT").val))
                    else:
                        raise ParseError(f"Invalid println arg token: {at.typ}")

                    if p.accept("COMMA"):
                        continue
                    p.expect("RPAREN")
                    break
            p.expect("SEMI")
            stmts.append(PrintCall(mode, args))
            continue

        raise ParseError(f"Unexpected token in main: {t.typ} {t.val!r}")

    # ensure EOF
    if p.peek() is not None:
        # allow trailing tokens only if whitespace/comments were stripped (they are)
        raise ParseError("Unexpected tokens after program end")

    return stmts


def c_escape_string_token(tok: str) -> str:
    # tok includes surrounding quotes; keep as-is for C since both use double quotes.
    return tok


def emit_c(stmts: List[Statement]) -> str:
    lines: List[str] = []
    lines.append("// Generated by MiniLang V1.0 (minilangc.py)")
    lines.append("#include <stdio.h>")
    lines.append("#include <stdlib.h>")
    lines.append("")
    lines.append("int main(void) {")

    # variable table: name -> type
    vartype: dict[str, str] = {}

    for st in stmts:
        if isinstance(st, VarDecl):
            if st.typ == "int":
                vartype[st.name] = "int"
                if st.value_kind != "number":
                    raise ParseError(f"Cannot assign string to int: {st.name}")
                lines.append(f"    int {st.name} = {st.value};")
            elif st.typ == "string":
                vartype[st.name] = "string"
                if st.value_kind != "string":
                    raise ParseError(f"Cannot assign number to string: {st.name} (V1.0 literals only)")
                lines.append(f"    const char* {st.name} = {st.value};")
            else:
                raise ParseError(f"Unknown type {st.typ}")

        elif isinstance(st, PrintCall):
            # Emit each argument with printf
            for kind, val in st.args:
                if kind == "string":
                    lines.append(f"    printf(%s);" % c_escape_string_token(val))
                elif kind == "number":
                    lines.append(f"    printf(\"%d\", {val});")
                elif kind == "ident":
                    t = vartype.get(val)
                    if t == "int":
                        lines.append(f"    printf(\"%d\", {val});")
                    elif t == "string":
                        lines.append(f"    printf(\"%s\", {val});")
                    else:
                        raise ParseError(f"Unknown identifier or unsupported type in println: {val}")
                else:
                    raise ParseError("Internal error")
            if st.mode == "break":
                lines.append("    printf(\"\\n\");")
        else:
            raise ParseError("Internal error")

    lines.append("    return 0;")
    lines.append("}")
    lines.append("")
    return "\n".join(lines)


def main(argv: List[str]) -> int:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("src", help="Path to .lang file")
    ap.add_argument("-o", "--out", default="out/out.c", help="Output C file")
    ap.add_argument("--build", action="store_true", help="Also build with gcc")
    ap.add_argument("--run", action="store_true", help="Run the produced binary (implies --build)")
    args = ap.parse_args(argv)

    with open(args.src, "r", encoding="utf-8") as f:
        src = f.read()

    toks = lex(src)
    p = Parser(toks)
    stmts = parse_program(p)
    c = emit_c(stmts)

    out_path = args.out
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(c)

    print(f"[MiniLang] Wrote C to: {out_path}")

    if args.run:
        args.build = True

    if args.build:
        exe_path = os.path.join(os.path.dirname(out_path), "a.out")
        cmd = ["gcc", out_path, "-O2", "-o", exe_path]
        print("[MiniLang] Building:", " ".join(cmd))
        subprocess.check_call(cmd)
        print(f"[MiniLang] Built: {exe_path}")

        if args.run:
            print("[MiniLang] Running:\n")
            subprocess.check_call([exe_path])

    return 0

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
